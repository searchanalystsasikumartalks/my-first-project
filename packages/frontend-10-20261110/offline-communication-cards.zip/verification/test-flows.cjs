const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const root=fs.existsSync(path.join(__dirname,'household-evidence-pack'))||fs.existsSync(path.join(__dirname,'heat-shift-brief'))||fs.existsSync(path.join(__dirname,'offline-communication-cards'))||fs.existsSync(path.join(__dirname,'accessibility-review-notebook'))?__dirname:path.dirname(__dirname);let results=[];
for(const slug of ['household-evidence-pack','accessibility-review-notebook','offline-communication-cards','heat-shift-brief']){
 if(!fs.existsSync(path.join(root,slug,'app.js')))continue;
 const nodes={},events={},storage={};let downloaded;
 function node(id){return nodes[id]??=( {value:'',textContent:'',innerHTML:'',disabled:false,files:[],dataset:{},click(){},reset(){},showModal(){this.open=true},close(){this.open=false}})}
 const ctx={document:{getElementById:node,addEventListener:(k,f)=>events[k]=f,createElement:()=>({click(){}})},window:{addEventListener(){}},localStorage:{getItem:k=>storage[k]??null,setItem:(k,v)=>storage[k]=v},crypto:{randomUUID:()=>String(Math.random())},Blob:class{constructor(v){downloaded=v.join('')}},URL:{createObjectURL:()=>'',revokeObjectURL(){}},confirm:()=>true,setTimeout:f=>f(),Date,console};vm.createContext(ctx);vm.runInContext(fs.readFileSync(path.join(root,slug,'app.js'),'utf8'),ctx);
 const set=(k,v)=>node(k).value=v;const run=s=>vm.runInContext(s,ctx);
 async function test(){
  if(slug==='household-evidence-pack'){set('name','<script>alert(1)</script>');set('room','Hall');set('notes','Recorded');await node('form').onsubmit({preventDefault(){}});assert(node('list').innerHTML.includes('&lt;script&gt;'));assert(!node('list').innerHTML.includes('<script>'));assert.equal(Object.keys(storage).length,0);}
  if(slug==='accessibility-review-notebook'){set('page','/contact');set('check','Keyboard and focus');set('outcome','Issue observed');set('notes','Focus not visible');node('form').onsubmit({preventDefault(){}});assert(node('list').innerHTML.includes('Focus not visible'));}
  if(slug==='offline-communication-cards'){set('text','Please wait');set('category','Everyday');node('form').onsubmit({preventDefault(){}});assert(node('list').innerHTML.includes('Please wait'));}
  if(slug==='heat-shift-brief'){set('work','Yard');set('controls','Water, shade, rest');set('response','Buddy check');node('form').onsubmit({preventDefault(){}});assert(node('list').innerHTML.includes('Water, shade, rest'));}
  assert.equal(run('entries.length'),1);node('export').onclick();assert.equal(JSON.parse(downloaded).entries.length,1);run('remove(entries[0].id)');assert.equal(run('entries.length'),0);assert(node('list').innerHTML.includes('empty'));return {app:slug,passed:true,checks:['initial empty state','create entry','render saved values','JSON export payload','confirmed deletion','empty state after delete',...(slug==='household-evidence-pack'?['HTML escaping','no browser persistence']:['localStorage write'])]};
 }
 results.push(test());
}
Promise.all(results).then(r=>{fs.writeFileSync(path.join(root,'test-results.json'),JSON.stringify(r,null,2));console.log(JSON.stringify(r,null,2))}).catch(e=>{console.error(e);process.exitCode=1});
