from playwright.sync_api import sync_playwright
from pathlib import Path
import json,threading,http.server,socketserver,os
root=Path(__file__).resolve().parent
if root.name=='verification': root=root.parent
os.chdir(root)
class Handler(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
server=socketserver.TCPServer(('127.0.0.1',0),Handler)
threading.Thread(target=server.serve_forever,daemon=True).start()
results={}
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 for slug in ['household-evidence-pack','accessibility-review-notebook','offline-communication-cards','heat-shift-brief']:
  if not (root/slug).exists(): continue
  page=browser.new_page(viewport={'width':390,'height':844});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto(f'http://127.0.0.1:{server.server_address[1]}/{slug}/')
  assert page.locator('h1').count()==1
  assert page.locator('meta[name="description"]').get_attribute('content')
  assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'),slug
  if slug=='household-evidence-pack':
   page.locator('#name').fill('<script>alert(1)</script>');page.locator('#room').fill('Living room');page.locator('#notes').fill('Sample only');page.locator('#add').click()
   page.wait_for_function("document.getElementById('count').textContent==='1'")
   assert page.locator('.item h3').inner_text()=='<script>alert(1)</script>'
  elif slug=='accessibility-review-notebook':
   page.locator('#page').fill('Example screen');page.locator('#notes').fill('Keyboard focus missing on navigation');page.locator('form button').click();page.locator('[data-state]').select_option('Retest needed')
  elif slug=='offline-communication-cards':
   page.locator('[data-preset]').first.click();page.locator('[data-show]').click();assert page.locator('#dialog').is_visible();page.keyboard.press('Escape');assert not page.locator('#dialog').is_visible()
   page.locator('#text').fill('I need some help');page.locator('form button').click()
  else:
   page.locator('#work').fill('Yard work');page.locator('#controls').fill('Shade, water, rest plan with supervisor');page.locator('#response').fill('Buddy checks and site access confirmed');page.locator('form button').click()
  count=int(page.locator('#count').inner_text());assert count>0
  page.on('dialog',lambda d:d.accept())
  with page.expect_download() as dl:page.locator('#export').click()
  out=dl.value.path();data=json.loads(Path(out).read_text());assert len(data['entries'])==count
  page.screenshot(path=str(root/slug/'screenshot-mobile.png'),full_page=True)
  page.set_viewport_size({'width':1440,'height':1000});assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
  page.screenshot(path=str(root/slug/'screenshot-desktop.png'),full_page=True)
  page.reload();assert int(page.locator('#count').inner_text())==(0 if slug=='household-evidence-pack' else count)
  if slug!='household-evidence-pack':
   page.locator('[data-remove]').first.click();assert int(page.locator('#count').inner_text())==count-1
  assert not errors,errors
  results[slug]={'passed':True,'checks':['mobile 390px no horizontal overflow','desktop 1440px no horizontal overflow','create entry','JSON export content','reload storage behavior','no JavaScript errors','unique title and description'],'notes':'Household session-only reset verified; other apps persisted and delete tested. Card modal Escape tested. Household text escaping tested.'}
  page.close()
 browser.close()
server.shutdown()
(root/'test-results.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
